# -*- coding: utf-8 -*-
"""
Created on Tue Jun 22 11:49:15 2021

@author: faradars
"""
import pandas as pd
data = pd.read_excel(r'C:\Users\faradars\Desktop\faradars\data.xlsx')
x = data.gender
y = data.height
import matplotlib.pyplot as plt
plt.scatter(x, y)
from scipy.stats import pearsonr
from scipy.stats import spearmanr

print(spearmanr(x, y))