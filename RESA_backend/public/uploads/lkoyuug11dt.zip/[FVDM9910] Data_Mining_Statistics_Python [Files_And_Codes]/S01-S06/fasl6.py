# -*- coding: utf-8 -*-
"""
Created on Fri Aug  6 19:32:33 2021

@author: faradars
"""
import pandas as pd
import numpy as np
data = pd.read_excel(r'C:\Users\faradars\Desktop\faradars\fasl6.xlsx')
data.dropna(inplace = True)
data.drop('name', axis = 1, inplace = True)
#data.fillna(data.mean(), inplace = True)

# from sklearn.impute import SimpleImputer
# imp = SimpleImputer(missing_values = np.nan,
#                     strategy = 'most_frequent')
# values = imp.fit_transform(data)

from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
data.gender = le.fit_transform(data.gender)
data.eye_color = le.fit_transform(data.eye_color)

from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MaxAbsScaler
scale1 = MinMaxScaler()
scale2 = StandardScaler()
scale3 = MaxAbsScaler()
data1 = scale1.fit_transform(data)
data2 = scale2.fit_transform(data)
data3 = scale3.fit_transform(data)

