# -*- coding: utf-8 -*-
"""
Created on Sun Jun 20 10:56:51 2021

@author: faradars
"""
print
a = [1, 10]
import matplotlib.pyplot as plt
plt.plot(a)