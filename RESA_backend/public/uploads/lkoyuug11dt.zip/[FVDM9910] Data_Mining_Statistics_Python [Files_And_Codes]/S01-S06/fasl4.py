# -*- coding: utf-8 -*-
"""
Created on Tue Jul  6 17:52:03 2021

@author: faradars
"""
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

from scipy.stats import bernoulli
a = bernoulli.rvs(size = 400, p = 0.001)
#print(pd.Series(x).value_counts())

b = np.random.binomial(n = 5, size = 10000, p = 0.1)
# plt.hist(y)

# poisson distribution
from numpy import random
c = random.poisson(lam = 2, size = 10000)
# print(list(x).count(6) / len(x))
# plt.hist(x)
d = random.uniform(low = 1, high = 3, size = 10)

#normal distribution
e = random.normal(size = 10000, loc = 175, scale = 1.3)
f = random.normal(size = 10000, loc = 175, scale = 2.3)
g = random.normal(size = 10000, loc = 184, scale = 1.8)
plt.hist(e, alpha = 1)
plt.hist(f, alpha = 0.5, color = 'red')
#plt.hist(g, alpha = 0.7, color = 'black')