# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 18:37:11 2021

@author: faradars
"""

# libraries
import statistics as st
import numpy as np
from scipy import stats

#data
nomarat = [20, 20, 18, 18, 20, 18, 17, 17, 18, 14, 12, 20]

#mean
a = np.mean(nomarat)
b = st.mean(nomarat)

#mode
c = stats.mode(nomarat)
d = st.mode(nomarat)

#median
e = st.median(nomarat)
f = np.median(nomarat)

#variance
g = np.var(nomarat)
h = st.variance(nomarat)
i = st.pvariance(nomarat)

#std
j = np.std(nomarat)
k = st.stdev(nomarat)
l = st.pstdev(nomarat)